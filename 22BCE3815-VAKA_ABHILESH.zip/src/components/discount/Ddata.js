const Ddata = [
  {
    cover: "./images/discount/boat.webp",
    name: "Boat Airdopes 161",
    price: "₹1099",
  },
  {
    cover: "./images/discount/noise.webp",
    name: "Noise Evolve 3",
    price: "₹1299",
  },
  {
    cover: "./images/discount/zebronics.webp",
    name: "Zebronics PSPK 8(Buddy 100)",
    price: "₹1399",
  },
  {
    cover: "./images/discount/trimmer.webp",
    name: "Philips BT3101/15 Trimmer",
    price: "₹799",
  },
  {
    cover: "./images/discount/fujifilm.webp",
    name: "FUJIFILM Instant Mini 11 Instant Camera(Blue)",
    price: "₹3999",
  },
  {
    cover: "./images/discount/cp plus.webp",
    name: "CP PLUS E-24A FULL HD WI-FI PT Camera with 360 Degree Camera",
    price: "₹799",
  },
  {
    cover: "./images/discount/mounter.webp",
    name: "MOUNTER Leather Wallet for Men ",
    price: "₹300",
  },
  {
    cover: "./images/discount/cherryland.webp",
    name: "Cherryland Laptop Sleeve Case 15.6 Inch Compatible with MacBook Pro 15",
    price: "₹199",
  },
  {
    cover: "./images/discount/tp link.webp",
    name: "TP-Link Archer AC1200 Archer C6 Wi-Fi Speed Up to 867 Mbps/5 GHz + 400Mbps/2.4 GHz",
    price: "₹1999",
  },
]
export default Ddata
