const Tdata = [
  {
    cover: "./images/top/category-1.png",
    para: "headphones",
    desc: "3k orders this week",
  },
  {
    cover: "./images/top/category-2.png",
    para: "watches",
    desc: "4k orders this week",
  },
  {
    cover: "./images/top/category-3.png",
    para: "sunglasses",
    desc: "3.2k orders this week",
  },
  {
    cover: "./images/top/category-2.png",
    para: "watch",
    desc: "1.6k orders this week",
  },
  {
    cover: "./images/top/category-3.png",
    para: "sunglass",
    desc: "2.5k orders this week",
  },
]

export default Tdata
