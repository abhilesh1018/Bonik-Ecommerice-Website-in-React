const Ndata = [
  {
    cover: "./images/arrivals/rayban.png",
    name: "Rayban Sunglasses",
    price: "699",
  },
  {
    cover: "./images/arrivals/dumbell.jpg",
    name: "Dumbells",
    price: "749",
  },
  {
    cover: "./images/arrivals/smartwatch.webp",
    name: "Smart Watch",
    price: "1099",
  },
  {
    cover: "./images/arrivals/firestick.webp",
    name: "Firestick",
    price: "299",
  },
  {
    cover: "./images/arrivals/batteries.png",
    name: "Batteries",
    price: "199",
  },
  {
    cover: "./images/arrivals/bonsai.png",
    name: "Bonsai tree",
    price: "499",
  },
]

export default Ndata
