const Sdata = [
  {
    id: 1,
    title: "50% Off For Your First Shopping(22BCE3815&VAKA ABHILESH)",
    desc: " Explore our vast selection of products ranging from fashion and electronics to All Accesories, and indulge in unbeatable savings.",
    cover: "./images/SlideCard/leather.png",
  },
  {
    id: 2,
    title: "50% Off For Your First Shopping(22BCE3815&VAKA ABHILESH)",
    desc: "Explore our vast selection of products ranging from fashion and electronics to All Accesories, and indulge in unbeatable savings.",
    cover: "./images/SlideCard/laptop.webp",
  },
  {
    id: 3,
    title: "50% Off For Your First Shopping(22BCE3815&VAKA ABHILESH)",
    desc: "Explore our vast selection of products ranging from fashion and electronics to All Accesories, and indulge in unbeatable savings.",
    cover: "./images/SlideCard/plant.webp",
  },
  {
    id: 4,
    title: "50% Off For Your First Shopping(22BCE3815&VAKA ABHILESH)",
    desc: "Explore our vast selection of products ranging from fashion and electronics to All Accesories, and indulge in unbeatable savings.",
    cover: "./images/SlideCard/slide-4.png",
  },
]
export default Sdata
